﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data
{
   public class Configuration
    {
        public const string Connection = "Server=.;Database=SalesDatabase;Integrated Security=true;";
    }
}
