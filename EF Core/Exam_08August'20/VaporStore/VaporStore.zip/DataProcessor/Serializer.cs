﻿namespace VaporStore.DataProcessor
{
    using System;
    using System.Linq;
    using Data;
    using Newtonsoft.Json;

    public static class Serializer
    {
        public static string ExportGamesByGenres(VaporStoreDbContext context, string[] genreNames)
        {
            var exportGenres = context.Genres.Where(g => genreNames.Any(gn => g.Name == gn)).Select(g => new
            {
                Id = g.Id,
                Genre = g.Name,
                Games = g.Games
                .Where(g => g.Purchases.Any())
                                    .Select(g => new
                                    {
                                        g.Id,
                                        Title = g.Name,
                                        Developer = g.Developer.Name,
                                        Tags = string.Join(", ", g.GameTags
                                        .Select(gt => gt.Tag.Name)),
                                        Players = g.Purchases.Count
                                    })
                                    .ToArray(),
                TotalPlayers = g.Games
                .SelectMany(g => g.Purchases).Count()
            }).ToArray();

            return JsonConvert.SerializeObject(exportGenres, Formatting.Indented);
        }

        public static string ExportUserPurchasesByType(VaporStoreDbContext context, string storeType)
        {
            throw new NotImplementedException();
        }
    }
}