﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
			@"Server=.;Database=VaporStore;Trusted_Connection=True";
	}
}